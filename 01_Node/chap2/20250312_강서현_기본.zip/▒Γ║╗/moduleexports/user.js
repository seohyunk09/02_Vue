const user = '홍길동';
module.exports = user; // user 변수 내보내기
