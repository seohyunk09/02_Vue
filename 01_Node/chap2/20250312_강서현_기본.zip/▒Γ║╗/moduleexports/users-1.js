const user1 = 'Kim';
const user2 = 'Lee';
const user3 = 'Choi';

export default { user1, user2 };
