const { user1, user2 } = require('./users-1.js');
const hello = require('./hello.js');

hello(user1);
hello(user2);
