import { goodbye as bye } from './greeting-1.mjs';

bye('홍길동');
