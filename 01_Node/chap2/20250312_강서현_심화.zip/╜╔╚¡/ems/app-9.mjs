import * as say from './greeting-1.mjs';

say.hi('홍길동');
say.goodbye('홍길동');
