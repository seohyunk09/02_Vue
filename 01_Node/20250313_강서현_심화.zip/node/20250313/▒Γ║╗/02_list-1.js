// 동기 함수 호출로 처리
const fs = require('fs');
let files = fs.readdirSync('./');
console.log(files);

// 비동기함수 호출로 처리
