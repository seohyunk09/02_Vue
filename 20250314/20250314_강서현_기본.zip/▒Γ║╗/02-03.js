const p1 = { name: 'john', age: 20 };
pl.age = 22;
console.log(p1);
pl = { name: 'lee', age: 25 };
